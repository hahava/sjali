package com.example.eeww9.sejong_alli;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by hahav on 2016-12-21.
 */

public class CustomListviewAdapterGroup extends BaseAdapter {
    private Context allMenuContext = null;
    private ArrayList<CustomItemGroup> allMenuListData = new ArrayList<CustomItemGroup>();
    CustomItemGroup addInfo;

    public CustomListviewAdapterGroup(Context allMenuContext) {
        super();
        this.allMenuContext = allMenuContext;
    }

    @Override
    public int getCount() {
        return allMenuListData.size();
    }

    @Override
    public Object getItem(int position) {
        return allMenuListData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void addItem(String cus, String custitle, String cusdate) {
        addInfo = new CustomItemGroup();
        addInfo.cus = cus;
        addInfo.cusTitle = custitle;
        addInfo.cusDate = cusdate;
        allMenuListData.add(addInfo);
    }

    private class ViewHolder {
        public TextView cus;
        public TextView CusTitle;
        public TextView CusDate;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        CustomListviewAdapterGroup.ViewHolder cusData;
        if (convertView == null) {
            cusData = new CustomListviewAdapterGroup.ViewHolder();

            LayoutInflater inflater = (LayoutInflater) allMenuContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.custom_view_group, null);

            //리스트에 들어갈 데이터
            cusData.cus = (TextView) convertView.findViewById(R.id.customTitleGroup);
            cusData.CusTitle = (TextView) convertView.findViewById(R.id.subject);
            cusData.CusDate = (TextView) convertView.findViewById(R.id.personnel);

            convertView.setTag(cusData);
        } else {
            cusData = (CustomListviewAdapterGroup.ViewHolder) convertView.getTag();
        }

        final CustomItemGroup allMenuData = allMenuListData.get(position);

        cusData.cus.setText(allMenuData.cus);
        cusData.CusTitle.setText(allMenuData.cusTitle);
        cusData.CusDate.setText("인원 "+allMenuData.cusDate+" 명");

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(allMenuContext, DetailsGroup.class);
                intent.putExtra("number", position);
                allMenuContext.startActivity(intent);
            }
        });
        return convertView;

    }
}
