package com.example.eeww9.sejong_alli;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class InDetails extends Activity {

    TextView attend;
    TextView date;
    TextView reception;
    TextView contents;
    TextView contact;
    TextView title;
    ImageButton kakaobtn,facebookbtn;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.in_detail_info);
        Intent intent = getIntent();
        int position;
        position = intent.getExtras().getInt("number");
        final InDetailsExample indetaildata = new InDetailsExample(position);

        attend = (TextView) findViewById(R.id.inside_attendCondition);
        date= (TextView) findViewById(R.id.inside_date);
        reception= (TextView) findViewById(R.id.inside_reception);
        contents= (TextView) findViewById(R.id.inside_contents);
        contact= (TextView) findViewById(R.id.inside_contactInformation);
        title= (TextView) findViewById(R.id.inside_Title);
        kakaobtn = (ImageButton) findViewById(R.id.inside_kakaoButton);
        facebookbtn = (ImageButton) findViewById(R.id.inside_facebookButton);

        attend.setText(indetaildata.inattend);
        date.setText(indetaildata.indate);
        reception.setText(indetaildata.inreception);
        contents.setText(indetaildata.incontents);
        contact.setText(indetaildata.incontact);
        title.setText(indetaildata.intitle);

        kakaobtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view){
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.setPackage("com.twitter.android");
                intent.putExtra(Intent.EXTRA_SUBJECT, "safsdfs");
                intent.putExtra(Intent.EXTRA_TEXT, "sdfasdfas");

                try {
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(InDetails.this, "트위터 앱이 없습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        facebookbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_SUBJECT, "dfsfa");
                intent.putExtra(Intent.EXTRA_TEXT, "fsdafdsafds");

                PackageManager packManager = getApplicationContext().getPackageManager();
                List<ResolveInfo> resolvedInfoList = packManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);

                boolean resolved = false;
                for(ResolveInfo resolveInfo: resolvedInfoList) {
                    if(resolveInfo.activityInfo.packageName.startsWith("com.facebook.katana")){
                        intent.setClassName(
                                resolveInfo.activityInfo.packageName,
                                resolveInfo.activityInfo.name );
                        resolved = true;
                        break;
                    }
                }

                if(resolved) {
                    startActivity(intent);

                } else {
                    Toast.makeText(InDetails.this, "페이스북 앱이 없습니다.", Toast.LENGTH_SHORT).show();
                }
            }

        });


    }
}
