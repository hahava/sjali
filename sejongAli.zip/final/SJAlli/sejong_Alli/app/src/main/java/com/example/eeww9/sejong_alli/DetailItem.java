package com.example.eeww9.sejong_alli;


import android.graphics.drawable.Drawable;

public class DetailItem {
    public String mainTitle;
    public Drawable secondImage;
    public String secondTitle;
    public String secondHost;
    public String secondDate;
    public String detAttend;
    public String detContents;
    public String detBenefits;
    public String detDate;
    public String detReception;
    public String detNotice;
    public String detContact;
}
