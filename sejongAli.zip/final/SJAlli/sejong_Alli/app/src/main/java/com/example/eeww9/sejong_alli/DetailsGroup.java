package com.example.eeww9.sejong_alli;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DetailsGroup extends Activity {


    TextView tv1;
    TextView tv2;
    TextView tv3;
    TextView tv4;
    TextView tv5;
    TextView tv6;
    TextView tv7;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_group);
        Intent intent = getIntent();
        int position;
        position = intent.getExtras().getInt("number");


        tv1 = (TextView) findViewById(R.id.GeditName);
        tv2 = (TextView) findViewById(R.id.GeditContents);
        tv3 = (TextView) findViewById(R.id.GeditMajor);
        tv4 = (TextView) findViewById(R.id.GeditPersonnel);
        tv5 = (TextView) findViewById(R.id.GeditTitle);
        tv6 = (TextView) findViewById(R.id.GeditSubject);
        tv7 = (TextView) findViewById(R.id.GeditPhone);

        tv1.setText(Group.Sresult.get(position).name);
        tv2.setText(Group.Sresult.get(position).contents);
        tv3.setText(Group.Sresult.get(position).major);
        tv4.setText(Group.Sresult.get(position).personel);
        tv5.setText(Group.Sresult.get(position).title);
        tv6.setText(Group.Sresult.get(position).subject);
        tv7.setText(Group.Sresult.get(position).cellPhone);

    }
}
