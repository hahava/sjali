package com.example.eeww9.sejong_alli;

/**
 * Created by hahav on 2016-12-21.
 */

public class CustomItemGroup {
    public String cus;
    public String cusTitle;
    public String cusDate;
}
