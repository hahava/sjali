package com.example.eeww9.sejong_alli;

/**
 * Created by eeww9 on 2016-12-21.
 */
public class InDetailItem {

    public String attend;
    public String date;
    public String reception;
    public String contents;
    public String contact;
    public String title;
}
