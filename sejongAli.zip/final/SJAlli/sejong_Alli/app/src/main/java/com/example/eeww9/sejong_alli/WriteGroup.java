package com.example.eeww9.sejong_alli;


import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.ArrayList;

public class WriteGroup extends Activity {

    EditText et1;
    EditText et2;
    EditText et3;
    EditText et4;
    EditText et5;
    EditText et6;
    EditText et7;
    Button button;

    static String title;
    static String subject;
    static String personnel;
    static String contents;
    static String namel;
    static String major;
    static String phone;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.write_group);
        Intent intent = getIntent();


        final EditText et1 = (EditText) findViewById(R.id.editTitle);
        final EditText et2 = (EditText) findViewById(R.id.editSubject);
        final EditText et3 = (EditText) findViewById(R.id.editPersonnel);
        final EditText et4 = (EditText) findViewById(R.id.editContents);
        final EditText et5 = (EditText) findViewById(R.id.editName);
        final EditText et6 = (EditText) findViewById(R.id.editMajor);
        final EditText et7 = (EditText) findViewById(R.id.editPhone);
        button = (Button) findViewById(R.id.btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                title=et1.getText().toString();
                subject=et2.getText().toString();
                personnel=et3.getText().toString();
                contents=et4.getText().toString();
                namel=et5.getText().toString();
                major=et6.getText().toString();
                phone=et7.getText().toString();
                SendPost sendPost = new SendPost();
                sendPost.execute();
                finish();
            }
        });
    }

    private class SendPost extends AsyncTask<Void, Void, String> {
        protected String doInBackground(Void... unused) {

            String content = executeClient();
            return content;
        }

        protected void onPostExecute(String result) {
            // 모두 작업을 마치고 실행할 일 (메소드 등등)
        }

        // 실제 전송하는 부분
        public String executeClient() {
            ArrayList<NameValuePair> post = new ArrayList<NameValuePair>();
            post.add(new BasicNameValuePair("title", title));
            post.add(new BasicNameValuePair("subject", subject));
            post.add(new BasicNameValuePair("personnel", personnel));
            post.add(new BasicNameValuePair("contents", contents));
            post.add(new BasicNameValuePair("namel", namel));
            post.add(new BasicNameValuePair("major", major));
            post.add(new BasicNameValuePair("phone", phone));
            // 연결 HttpClient 객체 생성
            HttpClient client = new DefaultHttpClient();

            // 객체 연결 설정 부분, 연결 최대시간 등등
            HttpParams params = client.getParams();
            HttpConnectionParams.setConnectionTimeout(params, 5000);
            HttpConnectionParams.setSoTimeout(params, 5000);

            // Post객체 생성
            HttpPost httpPost = new HttpPost("http://223.195.12.84:52273/insert");

            try {
                UrlEncodedFormEntity entity = new UrlEncodedFormEntity(post, "UTF-8");
                httpPost.setEntity(entity);
                client.execute(httpPost);
                return EntityUtils.getContentCharSet(entity);
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }


    }
}
