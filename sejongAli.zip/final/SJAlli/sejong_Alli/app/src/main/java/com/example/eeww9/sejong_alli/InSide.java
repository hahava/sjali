package com.example.eeww9.sejong_alli;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Switch;

@SuppressLint("ValidFragment")
public class InSide extends Fragment{
    Context mContext;
    Switch inOnOff;
    View view;
    //Example adding
    private ListView MenuList = null;
    private InSideListviewAdapter ListViewAdapter = null;

    public InSide(Context context){
        mContext = context;
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,  Bundle savedInstanceState) {
       if(view==null)
        view = inflater.inflate(R.layout.in_side, null);


        //Example
        MenuList=(ListView) view.findViewById(R.id.inList);
        ListViewAdapter = new InSideListviewAdapter(getActivity());
        MenuList.setAdapter(ListViewAdapter);

        ListViewAdapter.addItem(
                "시간 관리 전략",
                "재학생 선착순 20명",
                "선착순 마감 까지" );

        ListViewAdapter.addItem(
                "인생극장",
                "제한없음",
                "2016_12_19" );
        ListViewAdapter.addItem(
                "2018 평창올림픽 기념 SW공모전 참가 지원",
                "재학생",
                "2016_12_09" );

        ListViewAdapter.addItem(
                "2017-1학기 새날관 행복기숙사 재학생 입사 모집 안내",
                "세종대학교 재학생",
                "2017_01_09" );

        ListViewAdapter.addItem(
                "기초학력 증진 프로그램 신청.등록 안내",
                "수시모집 입학재학생 및 입학예정자",
                "2016_12_19" );


        return view;
    }
}
