package com.example.eeww9.sejong_alli;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class InSideListviewAdapter extends BaseAdapter{

    private Context allMenuContext = null;
    private ArrayList<InSideItem> allMenuListData = new ArrayList<InSideItem>();
    InSideItem addInfo;

    public InSideListviewAdapter(Context allMenuContext){
        super();
        this.allMenuContext = allMenuContext;
    }

    @Override
    public int getCount() {
        return allMenuListData.size();
    }

    @Override
    public Object getItem(int position) {
        return allMenuListData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void addItem( String intitle, String incondition,String indate){
        addInfo = new InSideItem();
        addInfo.inTitle = intitle;
        addInfo.inCondition = incondition;
        addInfo.inDate = indate;
        allMenuListData.add(addInfo);
    }

    private class ViewHolder{
        public TextView InCondition;
        public TextView InTitle;
        public TextView InDate;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder inData;
        if(convertView == null){
            inData = new ViewHolder();

            LayoutInflater inflater = (LayoutInflater)allMenuContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.custom_view_inside,null);

            //리스트에 들어갈 데이터
            inData.InCondition = (TextView) convertView.findViewById(R.id.in_condition);
            inData.InTitle = (TextView)convertView.findViewById(R.id.in_title);
            inData.InDate = (TextView)convertView.findViewById(R.id.in_date);

            convertView.setTag(inData);
        }
        else{
            inData = (ViewHolder)convertView.getTag();
        }

        InSideItem allMenuData = allMenuListData.get(position);

        inData.InTitle.setText(allMenuData.inTitle);
        inData.InDate.setText(allMenuData.inDate);
        inData.InCondition.setText(allMenuData.inCondition);

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(allMenuContext,InDetails.class);
                intent.putExtra("number", position);
                allMenuContext.startActivity(intent);
            }
        });



        return convertView;
    }
}
