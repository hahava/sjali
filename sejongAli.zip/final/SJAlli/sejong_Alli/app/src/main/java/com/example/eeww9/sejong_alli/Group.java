package com.example.eeww9.sejong_alli;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Switch;

import java.util.ArrayList;

@SuppressLint("ValidFragment")
public class Group extends Fragment {
    Context mContext;
    Switch groupOnOff;
    View view;
    ArrayList<DetailAdding> arr = new ArrayList<DetailAdding>();
    DetailAdding di = new DetailAdding();
    DetailParser parser;
    static ArrayList<DetailAdding> Sresult;

    //Example adding
    private ListView MenuList = null;
    private CustomListviewAdapterGroup ListViewAdapter = null;

    public Group(Context context) {
        mContext = context;
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (view == null)
            view = inflater.inflate(R.layout.group, null);


        //Example
        MenuList = (ListView) view.findViewById(R.id.groupList);
        ListViewAdapter = new CustomListviewAdapterGroup(getActivity());
        MenuList.setAdapter(ListViewAdapter);

        parser = new DetailParser();
        //floating Button
        new JsoupAsyncTask().execute(null, null, null);


        //floating Button
        FloatingActionButton ftb = (FloatingActionButton) view.findViewById(R.id.fab);
        ftb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, WriteGroup.class);
                startActivity(intent);
            }
        });

        return view;
    }

    public class JsoupAsyncTask extends AsyncTask<String, String, ArrayList<DetailAdding>> {
        protected void onPreExecute(String... params) {
            super.onPreExecute();
        }

        protected ArrayList<DetailAdding> doInBackground(String... params) {

            return parser.connectFest();
        }

        protected void onPostExecute(ArrayList<DetailAdding> result) {
            // 리스트뷰 여기에 구현하시면 됩니다.
            ListViewAdapter = new CustomListviewAdapterGroup(getActivity());
            MenuList.setAdapter(ListViewAdapter);
            Sresult=result;
            for (int i = 0; i < result.size(); i++) {
                ListViewAdapter.addItem(result.get(i).title, result.get(i).subject, result.get(i).personel);
            }

        }
    }

}
