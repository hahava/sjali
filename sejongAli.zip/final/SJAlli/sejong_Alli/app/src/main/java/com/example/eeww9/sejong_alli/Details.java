package com.example.eeww9.sejong_alli;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class Details extends Activity{

    TextView maintitle;
    TextView secondtitle;
    TextView secondhost;
    TextView seconddate;
    TextView attend;
    TextView contents;
    TextView benefits;
    TextView date;
    TextView reception;
    TextView notice;
    TextView contact;
    ImageView secondImage;
    ImageButton kakaobtn,facebookbtn;

    @SuppressLint("WrongViewCast")
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_info);
        Intent intent = getIntent();
        int position;
        position = intent.getExtras().getInt("number");
        final ExampleDetails detaildata = new ExampleDetails(position);

        maintitle = (TextView) findViewById(R.id.detailTitle);
        secondtitle = (TextView) findViewById(R.id.smallTitle);
        secondhost = (TextView) findViewById(R.id.smallHost);
        seconddate = (TextView) findViewById(R.id.smallDate);
        attend = (TextView) findViewById(R.id.attendCondition);
        contents = (TextView) findViewById(R.id.contents);
        benefits = (TextView) findViewById(R.id.benefits);
        date = (TextView) findViewById(R.id.date);
        reception = (TextView) findViewById(R.id.reception);
        notice = (TextView) findViewById(R.id.notice);
        contact = (TextView) findViewById(R.id.contactInformation);
        secondImage = (ImageView) findViewById(R.id.detailImage);
        kakaobtn = (ImageButton) findViewById(R.id.kakaoButton);
        facebookbtn = (ImageButton) findViewById(R.id.facebookButton);

        maintitle.setText(detaildata.mainTitle);
        secondtitle.setText(detaildata.secondTitle);
        secondhost.setText(detaildata.secondHost);
        seconddate.setText(detaildata.secondDate);
        attend.setText(detaildata.detAttend);
        contents.setText(detaildata.detContents);
        benefits.setText(detaildata.detBenefits);
        date.setText(detaildata.detDate);
        reception.setText(detaildata.detReception);
        notice.setText(detaildata.detNotice);
        contact.setText(detaildata.detContact);
//insert

        kakaobtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view){
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.setPackage("com.twitter.android");
                intent.putExtra(Intent.EXTRA_SUBJECT, "safsdfs");
                intent.putExtra(Intent.EXTRA_TEXT, "sdfasdfas");

                try {
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(Details.this, "트위터 앱이 없습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        facebookbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_SUBJECT, "dfsfa");
                intent.putExtra(Intent.EXTRA_TEXT, "fsdafdsafds");

                PackageManager packManager = getApplicationContext().getPackageManager();
                List<ResolveInfo> resolvedInfoList = packManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);

                boolean resolved = false;
                for(ResolveInfo resolveInfo: resolvedInfoList) {
                    if(resolveInfo.activityInfo.packageName.startsWith("com.facebook.katana")){
                        intent.setClassName(
                                resolveInfo.activityInfo.packageName,
                                resolveInfo.activityInfo.name );
                        resolved = true;
                        break;
                    }
                }

                if(resolved) {
                    startActivity(intent);

                } else {
                    Toast.makeText(Details.this, "페이스북 앱이 없습니다.", Toast.LENGTH_SHORT).show();
                }
            }

        });

        switch (position)
        {
            case 0:
                secondImage.setImageDrawable(getDrawable(R.drawable.out_one));
                break;
            case 1:
                secondImage.setImageDrawable(getDrawable(R.drawable.out_second));
                break;
            case 2:
                secondImage.setImageDrawable(getDrawable(R.drawable.out_third));
                break;
            case 3:
                secondImage.setImageDrawable(getDrawable(R.drawable.out_fourth));
                break;
            case 4:
                secondImage.setImageDrawable(getDrawable(R.drawable.out_fivth));
                break;

        }


    }
}
