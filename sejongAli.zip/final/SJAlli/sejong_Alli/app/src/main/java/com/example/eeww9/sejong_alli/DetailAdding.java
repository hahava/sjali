package com.example.eeww9.sejong_alli;

public class DetailAdding {
    public String title;
    public String subject;
    public String personel;
    public String contents;
    public String name;
    public String major;
    public String cellPhone;
    //제목 토의주제 인원수 내용 네임 메이져 셀폰넘버

    public String toString(){
        return title+","+subject+","+personel+","+contents+","+name+","+major+","+cellPhone+"\n";
    }
}
