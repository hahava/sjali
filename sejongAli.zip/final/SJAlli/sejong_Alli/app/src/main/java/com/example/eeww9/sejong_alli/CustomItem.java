package com.example.eeww9.sejong_alli;

import android.graphics.drawable.Drawable;

public class CustomItem {
    public Drawable cusImage;
    public String cusTitle;
    public String cusDate;
}
