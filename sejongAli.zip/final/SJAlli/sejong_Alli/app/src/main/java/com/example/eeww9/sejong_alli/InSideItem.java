package com.example.eeww9.sejong_alli;


public class InSideItem {
    public String inTitle;
    public String inCondition;
    public String inDate;
}
